console.log("extension working")
// let pics=document.getElementsByTagName("img")

// chrome.runtime.onMessage.addListener(gotMessage);
// function gotMessage(msg,sender,sendRes){}