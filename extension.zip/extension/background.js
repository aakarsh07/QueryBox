console.log("background");
chrome.browserAction.onClicked.addListener(buttonClick);

function buttonClick(tab){
	console.log("clicked")	
	chrome.pageCapture.saveAsMHTML({tabId : tab.id},(mhtmlData)=>{
		let name = tab.title
		name=name.replace("?","")
		
		let metaData=JSON.stringify({
			"url" : tab.url,
			"fileName": name,
			"searchName": tab.title
		}) + "\n";
	
		let blobarray= new Blob([metaData,mhtmlData],{ type: "text/plain" })
		let url = URL.createObjectURL(blobarray)		
		console.log(url)

		console.log(name)
		name=name+".mhtml"
		chrome.downloads.download({
            url: url,
            filename: name,
            saveAs: true
        });
	})	
}